#!/bin/bash -e
#docker run -p 389:389 -p 636:636 -p 1389:1389 --name ldap-service --hostname ldap-service --detach erikdevelopernot/openldap-ok
#docker run -p 6443:443 --name ldapadmin-service --hostname ldapadmin-service --link ldap-service:ldap-host --env PHPLDAPADMIN_LDAP_HOSTS=ldap-host --detach osixia/phpldapadmin

docker start ldap-service
docker start ldapadmin-service

PHPLDAP_IP=$(docker inspect -f "{{ .NetworkSettings.IPAddress }}" ldapadmin-service)

echo "Go to: https://$PHPLDAP_IP"
echo "Login DN: cn=admin,dc=example,dc=org"
echo "Password: admin"
