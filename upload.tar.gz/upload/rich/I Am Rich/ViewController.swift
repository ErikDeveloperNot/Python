//
//  ViewController.swift
//  I Am Rich
//
//  Created by User One on 11/3/17.
//  Copyright © 2017 User One. All rights reserved.
//

import UIKit
import OktaAuth
import OktaJWT


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        OktaAuth
            .login()
            .start(self) { response, error in
                if error != nil { print(error!) }
                
                // Success of Authorize call
                if let tokenResponse = response {
                    OktaAuth.tokens?.set(value: tokenResponse.accessToken!, forKey: "accessToken")
                    OktaAuth.tokens?.set(value: tokenResponse.idToken!, forKey: "idToken")
                    print("Success! Received accessToken: \(tokenResponse.accessToken!)")
                    print("Success! Received idToken: \(tokenResponse.idToken!)")
                    
//                    print("Authstate debugDescription: \(tokenResponse.authState.debugDescription)");
                    
                    // Now call /userinfo endpoint with the clientId to authenticate (openId)
                    OktaAuth.userinfo() { response, error in
                        if error != nil { print("Error: \(error!)") }
                        
                        if let userinfo = response {
                            userinfo.forEach { print("\($0): \($1)") }
                        }
                    }
                    
                    // Use the Swift JWT verifeir
                    var options = [
                        "audience": "0oa6w7amg0WwUDGP25d5",
                        "issuer": "https://dev-688534.okta.com/oauth2/default"
                    ] as [String: Any];
                    
                    let validator = OktaJWTValidator(options);
                    
                    // verify openId idToken (!!! Note audince for this is the clientId of the application)
                    do {
                        let valid = try validator.isValid(tokenResponse.idToken!)
                        print("idToken Valid: \(valid)")
                    } catch let error {
                        print("Error: \(error)")
                    }
                    
                    options["audience"] = "api://default";
                    let validator2 = OktaJWTValidator(options);
                    
                    // verify accessToken (!!!! Note audience if from the Authorize API server (default in this case)
                    do {
                        let valid = try validator2.isValid(tokenResponse.accessToken!)
                        print("accessToke Valid: \(valid)")
                    } catch let error {
                        print("Error: \(error)")
                    }
                    
                    // verify keys used if different from the endpoint /keys
                    // in this sample i use the same key from the endpoint https://dev-688534.okta.com/oauth2/v1/keys
                    // not sure when a custom key would be used??
                    let givenJWK = [
                        "kty": "RSA",
                        "alg": "RS256",
                        "kid": "LyMht4Er7JcL-p8vWhxAh9XEV7csoxIxy0KA8RAqA5c",
                        "use": "sig",
                        "e": "AQAB",
                        "n": "45uF3HNOsjDpzHMaYRz18woxzkWIjy62ZJj7t7mM6_1mJjtcaXRkpIakW1ReGx7IOLa4rRdXSWqB64h3rQBFGX0q9YC3Rrhujy5ZQKSlghYdvHE1Soqt-t6IyZtQo31mhA3mT4MdBtzNfgYsuobxIK2b-mV73t7U12AkUkSN5l1GmeNRc15avEckX2yOGFfs1srbBZ2uECJnGvl888G5JscVGdBf3Uly3h-4DP6KQPpyuzfjS3OI46QopTxhOGHttxkFBBkKW9OXar-kq8tcfiSdRd7F0kHOwYAtm9ydkfJu31GTJauUP0K-vRTxqPsVxlDyOaOYfoUbmOoigckeVQ"
                        ] as [String: String]
                    
                    let validator3 = OktaJWTValidator(options, jwk: givenJWK);
                    do {
                        let valid = try validator3.isValid(tokenResponse.accessToken!)
                        print("accessToke With (Potential Custom Key?) Valid: \(valid)")
                    } catch let error {
                        print("Error: \(error)")
                    }
                }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

