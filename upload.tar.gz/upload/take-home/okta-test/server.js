//https://support.okta.com/help/s/question/0D51Y00008cfYaBSAU/error-expected-audience-is-required?language=en_US

const express = require("express");
const cors = require("cors")
const OktaJwtVerifier = require('@okta/jwt-verifier');
const { response } = require("express");
const bodyParser = require('body-parser');


const app = express();
app.use(cors());
app.use(express.json())
app.use(bodyParser.urlencoded({extended: true}));

var tasks = [
  { title: 'Create SPA', 
    description: 'Create a client side single page application',
    completed: true
  },
  { title: 'Okta Auth', 
    description: 'Add Okta’s Sign-in Widget to SPA',
    completed: true
  },
  { title: 'Configure Console', 
    description: 'Setup needed configurations for org in Okta console',
    completed: true
  },
  { title: 'Enable MFA', 
    description: 'Setup login to use SMS MFA on first login',
    completed: true
  },
  { title: 'Configure Server', 
    description: 'Setup API endpoints that require an access token and uses Okta’s JWT Verifier',
    completed: true
  }
];

const oktaJwtVerifier = new OktaJwtVerifier({
  //issuer: 'https://dev-758287.okta.com/oauth2/default' // required
  issuer: 'https://dev-688534.okta.com/oauth2/default'
});


app.post("/postman" , function(request, response) {
  console.log(request.body);
  //console.log(response);
  response.send(`<h1>hello</h1><hr/><p>${request.body}</p>`);
});


app.get("/api/tasks", authenticationRequired, function(req, resp) {
  //console.log(req);

  resp.json({
    tasks
  });
});


app.post("/api/addTask", authenticationRequired, function(req, resp) {
  console.log(req.body);

  if (req.body.title.length > 0 && req.body.description.length > 0) {
    tasks.push(req.body);
    resp.status = 200;
    resp.send(null);
  } else {
    resp.status = 500;
    resp.send(null);
  }
});


app.get("/api/messages", authenticationRequired, function(req, resp) {
  //console.log(req);
  console.log("Auth Success??");
  resp.json({
    tasks
  });
});


app.listen(3000, function() {
  console.log("Server running on 3000");
});



function authenticationRequired(req, res, next) {
  //console.log(req);
  const authHeader = req.headers.authorization || '';
  const match = authHeader.match(/Bearer (.+)/);

  if (!match) {
    res.status(401);
    return next('Unauthorized');
  }

  const accessToken = match[1];

  return oktaJwtVerifier.verifyAccessToken(accessToken, 'api://default')
    .then((jwt) => {
      req.jwt = jwt;
      next();
    })
    .catch((err) => {
console.log('\n\n\nERROR auth\n\n\n');
console.log(req);
      res.status(401).send(err.message);
    });
};
