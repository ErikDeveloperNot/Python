const express = require("express");
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.urlencoded({extended: true}));


app.get("/index.html", function(req, resp) {
  console.log(__dirname);
  resp.sendFile(__dirname + "/index.html");
});

app.get("/", function(req, resp) {
  resp.redirect("/index.html");
});
 
app.get("/implicit/callback", function(req, resp) {
  console.log("Redirecting\n");
  //resp.redirect("/index.html");
  resp.sendFile(__dirname + "/index.html");
});

app.get("/examples/okta/index.html", function(req, resp) {
  console.log(__dirname);
  resp.sendFile(__dirname + "/index.html");
});


app.get("/scripts/index.js", function(req, resp) {
    // console.log('C-' + req.url);
    resp.sendFile(__dirname + "/scripts/index.js");
  });

app.get("/implicit/scripts/index.js", (req, resp) => resp.sendFile(__dirname + "/scripts/index.js"));
  
app.get("/examples/okta/css/style.css", function(req, resp) {
  // console.log('B-' + req.url);
  resp.sendFile(__dirname + "/css/style.css");
});

app.get("/implicit/css/style.css", (req, resp) => resp.sendFile(__dirname + "/css/style.css"));

app.get("/css/style.css", function(req, resp) {
    // console.log('C-' + req.url);
    resp.sendFile(__dirname + "/css/style.css");
  });
  
app.get("/examples/okta/scripts/index.js", function(req, resp) {
console.log('B-' + req.url);
  resp.sendFile(__dirname + "/scripts/index.js");
});



app.listen(8080, function() {
  console.log("Server running...");
});
