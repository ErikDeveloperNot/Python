const tableHeader = '<table class="table table-striped table-sm"><thead class="thead-dark"><tr><th scope="col">Task</th><th scope="col">Description</th><th scope="col">Completed</th></tr></thead>';
const logoutHead = '<div class="dropdown show"><a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">';
const logoutTail = '</a><div class="dropdown-menu" aria-labelledby="dropdownMenuLink"><a class="dropdown-item" href="#">Logout</a></div></div>';

var oktaSignIn;


function needLogin() {
    oktaSignIn = new OktaSignIn({
        // logo: '//logo.clearbit.com/okta.com',
        logo: 'https://www.okta.com/sites/all/themes/Okta/images/logos/developer/Dev_Logo-03_Large.png',
        //baseUrl: "https://dev-758287.okta.com",
	baseUrl: "https://dev-688534.okta.com",
        redirectUri: "http://localhost:8080/implicit/callback",
        //clientId: "0oaquefuyYPGfXa2p4x6",
        clientId: "0oa6vtzsfAZECEoS35d5",
        scopes: ['openid', 'profile', 'email'],
        pkce: true,
        authParams: {
            //issuer: "https://dev-758287.okta.com/oauth2/default",
            issuer: "https://dev-688534.okta.com/oauth2/default",
            //responseType: ['token', 'id_token'],
            display: 'page'
        },
        features: {
            registration: true,                 // Enable self-service registration flow
            rememberMe: true,                   // Setting to false will remove the checkbox to save username
            multiOptionalFactorEnroll: true,  // Allow users to enroll in multiple optional factors before finishing the authentication flow.
            //selfServiceUnlock: true,          // Will enable unlock in addition to forgotten password
            smsRecovery: true,                // Enable SMS-based account recovery
            //callRecovery: true,               // Enable voice call-based account recovery
            //router: true,                       // Leave this set to true for the API demo
        }
    });

    if (oktaSignIn.hasTokensInUrl()) {
        oktaSignIn.authClient.token.parseFromUrl().then(
            // If we get here, the user just logged in.
            function success(res) {
                var accessToken = res.tokens.accessToken;
                var idToken = res.tokens.idToken;

                oktaSignIn.authClient.tokenManager.add('accessToken', accessToken);
                oktaSignIn.authClient.tokenManager.add('idToken', idToken);
                console.log("accessToken: " + accessToken.accessToken);

                showLoginDetails(idToken.claims.email);
                getTasks(accessToken.accessToken);
            },
            function error(err) {
                console.error(err);
            }
        );
    } else {
        oktaSignIn.authClient.token.getUserInfo().then(function (user) {
            console.log("user: " + user);
            showLoginDetails(user.email);

            oktaSignIn.authClient.tokenManager.get('accessToken').then(function (tok) {
                console.log("TOKER-" + tok.accessToken);
                getTasks(tok.accessToken);
            }, function (err) {
                console.log("Couldnt get");
            });

            // document.getElementById("logout").style.display = 'block';
        }, function (error) {
            oktaSignIn.renderEl(
                { el: '#okta-login-container' },
                function success(res) { },
                function error(err) {
                    console.error(err);
                }
            );
        });
    }
}

function logout() {
    oktaSignIn.authClient.signOut();
    location.reload();
}

function showLoginDetails(email) {
    document.getElementById("messageBox").innerHTML = '<div class="login-text logout"><span class="logout"></span><strong>Logged in as, ' + email + '</strong></span><span class="logout"><button id="logout" class="btn btn-outline-dark btn-sm" onclick="logout()">Logout</button></span></div>';
    document.getElementById("messageBox").style.display = 'block';
    document.getElementById("addTask").style.display = 'block';
}

function getTasks(token) {
    var xmlHttp = new XMLHttpRequest();
    xmlHttp.open("GET", 'http://localhost:3000/api/tasks', true); // false for synchronous request
    xmlHttp.setRequestHeader("Authorization", 'Bearer ' + token);

    xmlHttp.addEventListener("load", (evnt) => {
        console.log(evnt);
        if (evnt.currentTarget.status === 200) {
            // console.log(evnt.currentTarget.responseText);
            let docRoot = JSON.parse(evnt.currentTarget.responseText);
            let tasksArry = docRoot.tasks;
            let tasks = tableHeader + "<tbody>";

            for (let i = 0; i < tasksArry.length; i++) {
                tasks += '<tr><td>' + tasksArry[i].title + '</td><td>' + tasksArry[i].description +
                    '</td><td>' + tasksArry[i].completed + '</td></tr>'
            }

            tasks += '</tbody></table>';

            document.getElementById("taskList").innerHTML = tasks;
            document.getElementById("taskList").style.display = 'block';
        } else {
            console.log("ERROR getTasks");
        }
    });

    xmlHttp.send(null);
}

function addTask() {

    oktaSignIn.authClient.tokenManager.get('accessToken').then(function (tok) {

        if (!tok) {
            alert("access token not found, login");
            logout();
        }

        let title = document.getElementById("taskTitle").value;
        let description = document.getElementById("taskDescription").value;
        let completed = document.getElementById("taskCompleted").checked;
        let data = { title: title, description: description, completed: completed };

        var xmlHttp = new XMLHttpRequest();
        xmlHttp.open("POST", 'http://localhost:3000/api/addTask', true); // false for synchronous request
        xmlHttp.setRequestHeader("Authorization", 'Bearer ' + tok.accessToken);
        xmlHttp.setRequestHeader("Content-Type", 'application/json');

        xmlHttp.addEventListener("load", (evnt) => {
            console.log(evnt);
            if (evnt.currentTarget.readyState === XMLHttpRequest.DONE && evnt.currentTarget.status === 200) {
                // console.log('---tok----' + tok.accessToken);
                getTasks(tok.accessToken);

            } else {
                console.log("ERROR addTask");
            }
        });

        xmlHttp.send(JSON.stringify(data));

    }, function (err) {
        console.log("Couldnt get token: " + err);
        alert("Error adding task: " + err);
        return;
    });
}
